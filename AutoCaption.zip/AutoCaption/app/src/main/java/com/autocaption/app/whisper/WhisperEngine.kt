package com.autocaption.app.whisper

import com.autocaption.app.caption.RawWord
import com.whispercpp.whisper.WhisperLib
import com.whispercpp.whisper.WhisperProgressListener
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Owns the native whisper context. whisper.cpp must only be touched from one thread at a time,
 * so everything runs on a single dedicated thread.
 */
class WhisperEngine {

    private val executor = Executors.newSingleThreadExecutor()
    private val dispatcher = executor.asCoroutineDispatcher()

    private var contextPtr = 0L
    private var loadedModelPath: String? = null

    /**
     * @param language whisper language code ("ur", "hi", "en", ...) or "auto"
     * @param onProgress 0..100
     */
    suspend fun transcribe(
        modelPath: String,
        audio: FloatArray,
        language: String,
        onProgress: (Int) -> Unit
    ): List<RawWord> = withContext(dispatcher) {
        if (contextPtr == 0L || loadedModelPath != modelPath) {
            freeLocked()
            val ptr = WhisperLib.initContext(modelPath)
            if (ptr == 0L) {
                throw IllegalStateException("Could not load the speech model. Delete the app data and download it again.")
            }
            contextPtr = ptr
            loadedModelPath = modelPath
        }

        val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)
        val rc = WhisperLib.fullTranscribe(
            contextPtr,
            threads,
            language,
            audio,
            WhisperProgressListener { percent -> onProgress(percent) }
        )
        if (rc != 0) throw IllegalStateException("Speech recognition failed (code $rc).")

        readWords()
    }

    private fun readWords(): List<RawWord> {
        val count = WhisperLib.getSegmentCount(contextPtr)

        // One whisper segment == one word, but a multi-byte UTF-8 character (Urdu, Hindi, Chinese ...)
        // can be cut between two segments. Glue such fragments back together before decoding.
        val bytes = ArrayList<ByteArrayOutputStream>()
        val starts = ArrayList<Long>()
        val ends = ArrayList<Long>()

        for (i in 0 until count) {
            val b = WhisperLib.getSegmentBytes(contextPtr, i)
            val t0 = WhisperLib.getSegmentT0(contextPtr, i) * 10L
            val t1 = WhisperLib.getSegmentT1(contextPtr, i) * 10L
            val isContinuation = b.isNotEmpty() && (b[0].toInt() and 0xC0) == 0x80
            if (isContinuation && bytes.isNotEmpty()) {
                bytes.last().write(b)
                ends[ends.lastIndex] = maxOf(ends.last(), t1)
            } else {
                bytes.add(ByteArrayOutputStream().also { it.write(b) })
                starts.add(t0)
                ends.add(t1)
            }
        }

        return bytes.indices.map { i ->
            RawWord(String(bytes[i].toByteArray(), Charsets.UTF_8), starts[i], ends[i])
        }
    }

    private fun freeLocked() {
        if (contextPtr != 0L) {
            WhisperLib.freeContext(contextPtr)
            contextPtr = 0L
            loadedModelPath = null
        }
    }

    fun close() {
        executor.execute { freeLocked() }
        executor.shutdown()
    }
}
