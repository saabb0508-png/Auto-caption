package com.autocaption.app.caption

/** One word exactly as whisper produced it (time in milliseconds). */
data class RawWord(val text: String, val startMs: Long, val endMs: Long)

data class Word(
    val text: String,
    val startMs: Long,
    val endMs: Long,
    /** true if a space belongs in front of this word (false for e.g. Chinese/Japanese tokens) */
    val spaceBefore: Boolean
)

/** One caption (what is shown on screen / one SRT block). */
data class CaptionLine(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val words: List<Word>
)

enum class CaptionPosition { Top, Middle, Bottom }

enum class CaptionFont(val label: String) {
    Sans("Sans"),
    Serif("Serif"),
    Mono("Mono"),
    Cursive("Cursive")
}

/** Colors are stored as ARGB longs so this class has no UI dependency. */
data class CaptionStyle(
    val font: CaptionFont = CaptionFont.Sans,
    val sizeSp: Float = 22f,
    val bold: Boolean = true,
    val textColor: Long = 0xFFFFFFFF,
    val boxEnabled: Boolean = true,
    val boxOpacity: Float = 0.55f,
    val outline: Boolean = true,
    val position: CaptionPosition = CaptionPosition.Bottom,
    /** CapCut style: the word being spoken right now gets highlightColor */
    val wordHighlight: Boolean = true,
    val highlightColor: Long = 0xFFFFD60A
)
