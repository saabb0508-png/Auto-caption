package com.autocaption.app.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder

/**
 * Decodes the audio track of a video and returns 16 kHz, mono, float samples (-1..1),
 * which is exactly what whisper.cpp expects.
 *
 * Samples are down-mixed and resampled while decoding (streaming), so a long video
 * never needs a huge raw 44.1/48 kHz buffer in memory.
 */
object AudioExtractor {

    private const val TARGET_RATE = 16_000

    class NoAudioException : Exception("This video has no audio track.")

    suspend fun extractPcm16kMono(
        context: Context,
        uri: Uri,
        onProgress: (Float) -> Unit = {}
    ): FloatArray = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)

            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    inputFormat = format
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) throw NoAudioException()

            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
            val durationUs =
                if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) inputFormat.getLong(MediaFormat.KEY_DURATION) else 0L

            var sampleRate =
                if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
            var channels =
                if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var floatPcm = false

            val codec = MediaCodec.createDecoderByType(mime)
            try {
                codec.configure(inputFormat, null, null, 0)
                codec.start()

                val info = MediaCodec.BufferInfo()
                val timeoutUs = 10_000L
                var inputDone = false
                var outputDone = false
                var sink: PcmSink? = null
                var lastReport = 0f

                while (!outputDone) {
                    ensureActive()

                    if (!inputDone) {
                        val inIndex = codec.dequeueInputBuffer(timeoutUs)
                        if (inIndex >= 0) {
                            val inBuf = codec.getInputBuffer(inIndex)
                            val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                            if (size < 0) {
                                codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val sampleTime = extractor.sampleTime
                                codec.queueInputBuffer(inIndex, 0, size, sampleTime, 0)
                                extractor.advance()
                                if (durationUs > 0) {
                                    val p = (sampleTime.toFloat() / durationUs).coerceIn(0f, 1f)
                                    if (p - lastReport >= 0.02f) {
                                        lastReport = p
                                        onProgress(p)
                                    }
                                }
                            }
                        }
                    }

                    val outIndex = codec.dequeueOutputBuffer(info, timeoutUs)
                    when {
                        outIndex >= 0 -> {
                            if (info.size > 0) {
                                val outBuf = codec.getOutputBuffer(outIndex)
                                if (outBuf != null) {
                                    outBuf.position(info.offset)
                                    outBuf.limit(info.offset + info.size)
                                    outBuf.order(ByteOrder.nativeOrder())
                                    val activeSink = sink ?: PcmSink(sampleRate).also { sink = it }
                                    val ch = channels.coerceAtLeast(1)
                                    if (floatPcm) {
                                        val fb = outBuf.asFloatBuffer()
                                        while (fb.remaining() >= ch) {
                                            var sum = 0f
                                            for (c in 0 until ch) sum += fb.get()
                                            activeSink.push(sum / ch)
                                        }
                                    } else {
                                        val sb = outBuf.asShortBuffer()
                                        while (sb.remaining() >= ch) {
                                            var sum = 0f
                                            for (c in 0 until ch) sum += sb.get() / 32768f
                                            activeSink.push(sum / ch)
                                        }
                                    }
                                }
                            }
                            codec.releaseOutputBuffer(outIndex, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = codec.outputFormat
                            if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                                floatPcm = f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                            }
                        }
                        else -> Unit // INFO_TRY_AGAIN_LATER etc.
                    }
                }

                onProgress(1f)
                val result = sink?.result() ?: FloatArray(0)
                if (result.isEmpty()) throw NoAudioException()
                result
            } finally {
                try {
                    codec.stop()
                } catch (_: Exception) {
                }
                codec.release()
            }
        } finally {
            extractor.release()
        }
    }

    /** Streaming linear-interpolation resampler to 16 kHz with a growable output buffer. */
    private class PcmSink(srcRate: Int) {
        private val ratio = srcRate.toDouble() / TARGET_RATE
        private var buffer = FloatArray(TARGET_RATE * 60)
        private var size = 0
        private var count = 0L
        private var previous = 0f
        private var outPos = 0.0

        fun push(x: Float) {
            if (count == 0L) {
                while (outPos <= 0.0) {
                    emit(x)
                    outPos += ratio
                }
            } else {
                val index = count.toDouble()
                while (outPos <= index) {
                    val frac = (outPos - (index - 1)).toFloat()
                    emit(previous + (x - previous) * frac)
                    outPos += ratio
                }
            }
            previous = x
            count++
        }

        private fun emit(value: Float) {
            if (size == buffer.size) {
                buffer = buffer.copyOf(buffer.size + buffer.size / 2)
            }
            buffer[size++] = value.coerceIn(-1f, 1f)
        }

        fun result(): FloatArray = buffer.copyOf(size)
    }
}
