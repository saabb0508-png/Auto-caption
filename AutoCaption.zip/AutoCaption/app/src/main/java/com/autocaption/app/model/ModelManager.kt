package com.autocaption.app.model

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Multilingual Whisper models (NOT the ".en" ones, those only know English). */
enum class WhisperModel(
    val fileName: String,
    val title: String,
    val approxMb: Int,
    val minBytes: Long
) {
    BASE("ggml-base.bin", "Base", 142, 100_000_000L),
    SMALL("ggml-small.bin", "Small", 466, 400_000_000L)
}

class ModelManager(private val context: Context) {

    private fun modelsDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun file(model: WhisperModel): File = File(modelsDir(), model.fileName)

    fun isReady(model: WhisperModel): Boolean {
        val f = file(model)
        return f.exists() && f.length() >= model.minBytes
    }

    /** Downloads the model once from Hugging Face. [onProgress] gets 0..1 */
    suspend fun download(model: WhisperModel, onProgress: (Float) -> Unit) =
        withContext(Dispatchers.IO) {
            val target = file(model)
            val partial = File(modelsDir(), model.fileName + ".part")
            val url = URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${model.fileName}")
            var connection: HttpURLConnection? = null
            try {
                connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AutoCaption/1.0")
                }
                val code = connection.responseCode
                if (code !in 200..299) throw IOException("Model download failed (HTTP $code). Check your internet connection.")

                val reported = connection.contentLengthLong
                val total = if (reported > 0) reported else model.approxMb * 1_000_000L

                var downloaded = 0L
                var lastPercent = -1
                connection.inputStream.use { input ->
                    FileOutputStream(partial).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            val percent = ((downloaded * 100) / total).toInt().coerceIn(0, 99)
                            if (percent != lastPercent) {
                                lastPercent = percent
                                onProgress(percent / 100f)
                            }
                        }
                    }
                }

                if (partial.length() < model.minBytes) {
                    throw IOException("Downloaded file is incomplete. Please try again.")
                }
                if (target.exists()) target.delete()
                if (!partial.renameTo(target)) throw IOException("Could not save the model file.")
                onProgress(1f)
            } catch (t: Throwable) {
                partial.delete()
                throw t
            } finally {
                connection?.disconnect()
            }
        }
}
