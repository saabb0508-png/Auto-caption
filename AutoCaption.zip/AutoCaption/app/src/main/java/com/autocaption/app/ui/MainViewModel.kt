package com.autocaption.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autocaption.app.audio.AudioExtractor
import com.autocaption.app.caption.AUTO_LANGUAGE
import com.autocaption.app.caption.CaptionBuilder
import com.autocaption.app.caption.CaptionLine
import com.autocaption.app.caption.CaptionStyle
import com.autocaption.app.caption.Language
import com.autocaption.app.export.FileExporter
import com.autocaption.app.model.ModelManager
import com.autocaption.app.model.WhisperModel
import com.autocaption.app.whisper.WhisperEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface Stage {
    data object Idle : Stage

    /** progress == null means "unknown / indeterminate" */
    data class Working(val label: String, val progress: Float?) : Stage

    data object Done : Stage
}

data class UiState(
    val stage: Stage = Stage.Idle,
    val error: String? = null,
    val videoUri: Uri? = null,
    val videoName: String = "captions",
    val model: WhisperModel = WhisperModel.SMALL,
    val language: Language = AUTO_LANGUAGE,
    val lines: List<CaptionLine> = emptyList(),
    val style: CaptionStyle = CaptionStyle()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val models = ModelManager(application)
    private val engine = WhisperEngine()

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null

    fun setModel(model: WhisperModel) = _state.update { it.copy(model = model) }

    fun setLanguage(language: Language) = _state.update { it.copy(language = language) }

    fun setStyle(style: CaptionStyle) = _state.update { it.copy(style = style) }

    fun isModelReady(model: WhisperModel): Boolean = models.isReady(model)

    fun updateLineText(id: Int, text: String) {
        _state.update { s ->
            s.copy(lines = s.lines.map { if (it.id == id) CaptionBuilder.withText(it, text) else it })
        }
    }

    fun cancel() {
        job?.cancel()
    }

    /** Back to the start screen so another video can be chosen. */
    fun reset() {
        job?.cancel()
        _state.update { it.copy(stage = Stage.Idle, error = null, videoUri = null, lines = emptyList()) }
    }

    fun onVideoPicked(uri: Uri) {
        job?.cancel()
        val app = getApplication<Application>()
        val model = _state.value.model
        val language = _state.value.language

        job = viewModelScope.launch {
            _state.update {
                it.copy(
                    videoUri = uri,
                    videoName = FileExporter.displayName(app, uri),
                    lines = emptyList(),
                    error = null,
                    stage = Stage.Working("Preparing…", null)
                )
            }
            try {
                // 1) Model (downloaded only the first time)
                if (!models.isReady(model)) {
                    val label = "Downloading the ${model.title} speech model (${model.approxMb} MB, first time only)…"
                    _state.update { it.copy(stage = Stage.Working(label, 0f)) }
                    models.download(model) { p ->
                        _state.update { s -> s.copy(stage = Stage.Working(label, p)) }
                    }
                }

                // 2) Audio from the video -> 16 kHz mono
                _state.update { it.copy(stage = Stage.Working("Extracting audio from the video…", 0f)) }
                val audio = AudioExtractor.extractPcm16kMono(app, uri) { p ->
                    _state.update { s -> s.copy(stage = Stage.Working("Extracting audio from the video…", p)) }
                }

                // 3) Speech recognition with word timestamps
                val label = "Recognising speech… (a long video can take a few minutes)"
                _state.update { it.copy(stage = Stage.Working(label, 0f)) }
                val words = engine.transcribe(
                    models.file(model).absolutePath,
                    audio,
                    language.code
                ) { percent ->
                    _state.update { s -> s.copy(stage = Stage.Working(label, percent / 100f)) }
                }

                val lines = CaptionBuilder.fromRaw(words)
                if (lines.isEmpty()) {
                    _state.update {
                        it.copy(stage = Stage.Idle, error = "No speech was found in this video.")
                    }
                } else {
                    _state.update { it.copy(stage = Stage.Done, lines = lines) }
                }
            } catch (e: CancellationException) {
                _state.update { it.copy(stage = Stage.Idle) }
                throw e
            } catch (e: AudioExtractor.NoAudioException) {
                fail(e.message ?: "This video has no audio.")
            } catch (e: OutOfMemoryError) {
                fail("The phone ran out of memory. Try a shorter video or the Base model.")
            } catch (e: Throwable) {
                fail(e.message ?: "Something went wrong.")
            }
        }
    }

    private fun fail(message: String) {
        _state.update { it.copy(stage = Stage.Idle, error = message) }
    }

    override fun onCleared() {
        job?.cancel()
        engine.close()
        super.onCleared()
    }
}
