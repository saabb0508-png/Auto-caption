package com.autocaption.app.caption

import java.util.Locale

object SubtitleWriter {

    fun toSrt(lines: List<CaptionLine>): String {
        val usable = lines.filter { it.text.isNotBlank() }
        return buildString {
            usable.forEachIndexed { index, line ->
                append(index + 1).append('\n')
                append(time(line.startMs, ',')).append(" --> ").append(time(line.endMs, ',')).append('\n')
                append(cleanText(line.text)).append("\n\n")
            }
        }
    }

    fun toVtt(lines: List<CaptionLine>): String {
        val usable = lines.filter { it.text.isNotBlank() }
        return buildString {
            append("WEBVTT\n\n")
            usable.forEach { line ->
                append(time(line.startMs, '.')).append(" --> ").append(time(line.endMs, '.')).append('\n')
                append(cleanText(line.text)).append("\n\n")
            }
        }
    }

    /** Subtitle files must not contain blank lines inside a block. */
    private fun cleanText(text: String): String =
        text.trim().replace(Regex("\\n\\s*\\n+"), "\n")

    fun time(ms: Long, separator: Char): String {
        val total = ms.coerceAtLeast(0)
        val h = total / 3_600_000
        val m = (total % 3_600_000) / 60_000
        val s = (total % 60_000) / 1000
        val milli = total % 1000
        return "%02d:%02d:%02d%c%03d".format(Locale.ROOT, h, m, s, separator, milli)
    }

    /** Short label for the editor list, e.g. 01:23.4 */
    fun shortTime(ms: Long): String {
        val total = ms.coerceAtLeast(0)
        val m = total / 60_000
        val s = (total % 60_000) / 1000
        val tenth = (total % 1000) / 100
        return "%02d:%02d.%d".format(Locale.ROOT, m, s, tenth)
    }
}
