package com.autocaption.app.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException

enum class SubtitleFormat(val extension: String, val mime: String) {
    SRT("srt", "application/x-subrip"),
    VTT("vtt", "text/vtt")
}

object FileExporter {

    /** File name of the picked video without extension; safe to use as a file name. */
    fun displayName(context: Context, uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0)
                }
            }
        } catch (_: Exception) {
        }
        val base = (name ?: "captions").substringBeforeLast('.', name ?: "captions")
        val cleaned = base.replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "_").trim().take(60)
        return cleaned.ifEmpty { "captions" }
    }

    /** Saves into the public Downloads folder. Returns a message for the user. */
    fun saveToDownloads(context: Context, baseName: String, format: SubtitleFormat, content: String): String {
        val fileName = "$baseName.${format.extension}"
        val bytes = content.toByteArray(Charsets.UTF_8)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, format.mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Could not create the file in Downloads.")
            val stream = resolver.openOutputStream(uri) ?: throw IOException("Could not write the file.")
            stream.use { it.write(bytes) }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return "Saved to Downloads: $fileName"
        }

        // Android 8/9: no storage permission needed for the app's own external folder.
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        dir.mkdirs()
        val file = File(dir, fileName)
        file.writeBytes(bytes)
        return "Saved: ${file.absolutePath}"
    }

    /** Opens the Android share sheet with the subtitle file attached. */
    fun share(context: Context, baseName: String, format: SubtitleFormat, content: String) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "$baseName.${format.extension}")
        file.writeText(content, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Share subtitles").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
