package com.autocaption.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.autocaption.app.caption.CaptionFont
import com.autocaption.app.caption.CaptionLine
import com.autocaption.app.caption.CaptionPosition
import com.autocaption.app.caption.CaptionStyle
import com.autocaption.app.caption.LANGUAGES
import com.autocaption.app.caption.Language
import com.autocaption.app.caption.SubtitleWriter
import com.autocaption.app.export.FileExporter
import com.autocaption.app.export.SubtitleFormat
import com.autocaption.app.model.WhisperModel
import kotlinx.coroutines.delay

private val TEXT_COLORS = listOf(0xFFFFFFFF, 0xFFFFD60A, 0xFF00E5FF, 0xFF39FF14, 0xFFFF4DA6, 0xFF000000)
private val HIGHLIGHT_COLORS = listOf(0xFFFFD60A, 0xFF00E5FF, 0xFF39FF14, 0xFFFF4DA6, 0xFFFF6B35, 0xFFFFFFFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onVideoPicked(uri)
    }
    val pickVideo: () -> Unit = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    // ---- video player (only exists once captions are ready) ----
    val isDone = state.stage == Stage.Done
    val videoUri = state.videoUri
    val player: ExoPlayer? = remember(videoUri, isDone) {
        if (isDone && videoUri != null) {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(videoUri))
                prepare()
            }
        } else {
            null
        }
    }
    DisposableEffect(player) {
        onDispose { player?.release() }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, player) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) player?.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var positionMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) {
        while (true) {
            positionMs = player?.currentPosition ?: 0L
            delay(40)
        }
    }

    val lines = state.lines
    val activeLineId by remember(lines) {
        derivedStateOf { lines.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }?.id }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("AutoCaption") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (val stage = state.stage) {
                is Stage.Working -> {
                    item(key = "working") { WorkingCard(stage, onCancel = { vm.cancel() }) }
                }

                is Stage.Idle -> {
                    item(key = "start") {
                        StartCard(
                            state = state,
                            isModelReady = { vm.isModelReady(it) },
                            onModel = { vm.setModel(it) },
                            onLanguage = { vm.setLanguage(it) },
                            onPick = pickVideo
                        )
                    }
                }

                is Stage.Done -> {
                    item(key = "player") {
                        VideoWithCaptions(player, positionMs, lines, state.style)
                    }
                    item(key = "export") {
                        ExportSection(state.videoName, lines)
                    }
                    item(key = "style") {
                        StylePanel(state.style) { vm.setStyle(it) }
                    }
                    item(key = "edit-title") {
                        Text("Edit captions", style = MaterialTheme.typography.titleMedium)
                    }
                    items(lines, key = { it.id }) { line ->
                        LineEditor(
                            line = line,
                            active = activeLineId == line.id,
                            onSeek = { player?.seekTo(line.startMs) },
                            onChange = { vm.updateLineText(line.id, it) }
                        )
                    }
                    item(key = "another") {
                        OutlinedButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Choose another video")
                        }
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------
// Start / progress
// --------------------------------------------------------------------------------------

@Composable
private fun StartCard(
    state: UiState,
    isModelReady: (WhisperModel) -> Boolean,
    onModel: (WhisperModel) -> Unit,
    onLanguage: (Language) -> Unit,
    onPick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Automatic captions for any video", style = MaterialTheme.typography.titleLarge)
            Text(
                "Everything runs on your phone, free. The speech model is downloaded once; after that no internet is needed.",
                style = MaterialTheme.typography.bodyMedium
            )

            Text("Speech model", style = MaterialTheme.typography.titleSmall)
            WhisperModel.values().forEach { model ->
                val description = when (model) {
                    WhisperModel.BASE -> "Faster. Good for clear English."
                    WhisperModel.SMALL -> "Slower, much better for Urdu, Hindi and other languages."
                }
                val ready = if (isModelReady(model)) " (downloaded)" else ""
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onModel(model) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = state.model == model, onClick = { onModel(model) })
                    Column {
                        Text("${model.title} - ~${model.approxMb} MB$ready")
                        Text(description, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            LanguagePicker(selected = state.language, onSelect = onLanguage)

            val error = state.error
            if (error != null) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }

            Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
                Text("Choose video from gallery")
            }
        }
    }
}

@Composable
private fun LanguagePicker(selected: Language, onSelect: (Language) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Spoken language: ${selected.name}")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            LANGUAGES.forEach { language ->
                DropdownMenuItem(
                    text = {
                        Text(if (language.code == "auto") language.name else "${language.name} (${language.code})")
                    },
                    onClick = {
                        onSelect(language)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun WorkingCard(stage: Stage.Working, onCancel: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stage.label, style = MaterialTheme.typography.titleMedium)
            val progress = stage.progress
            if (progress == null) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text("${(progress * 100).toInt()}%")
            }
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
        }
    }
}

// --------------------------------------------------------------------------------------
// Player + live captions
// --------------------------------------------------------------------------------------

@Composable
private fun VideoWithCaptions(
    exoPlayer: ExoPlayer?,
    positionMs: Long,
    lines: List<CaptionLine>,
    style: CaptionStyle
) {
    var aspect by remember(exoPlayer) { mutableFloatStateOf(16f / 9f) }
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    aspect = (videoSize.width * videoSize.pixelWidthHeightRatio) / videoSize.height
                }
            }
        }
        exoPlayer?.addListener(listener)
        onDispose { exoPlayer?.removeListener(listener) }
    }

    val activeLine = lines.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
    val activeWord = activeLine?.words?.indexOfLast { positionMs >= it.startMs } ?: -1

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .heightIn(max = 460.dp)
                .aspectRatio(aspect.coerceIn(0.4f, 2.5f))
                .background(Color.Black)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = true
                        this.player = exoPlayer
                    }
                },
                update = { view -> view.player = exoPlayer }
            )

            if (activeLine != null && activeLine.text.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = 12.dp,
                            bottom = if (style.position == CaptionPosition.Bottom) 56.dp else 12.dp
                        ),
                    contentAlignment = when (style.position) {
                        CaptionPosition.Top -> Alignment.TopCenter
                        CaptionPosition.Middle -> Alignment.Center
                        CaptionPosition.Bottom -> Alignment.BottomCenter
                    }
                ) {
                    CaptionText(activeLine, activeWord, style)
                }
            }
        }
    }
}

@Composable
private fun CaptionText(line: CaptionLine, activeWord: Int, style: CaptionStyle) {
    val highlight = if (style.wordHighlight) activeWord else -1
    val annotated = remember(line, highlight, style.highlightColor) {
        buildCaptionText(line, highlight, Color(style.highlightColor))
    }

    val family = when (style.font) {
        CaptionFont.Sans -> FontFamily.SansSerif
        CaptionFont.Serif -> FontFamily.Serif
        CaptionFont.Mono -> FontFamily.Monospace
        CaptionFont.Cursive -> FontFamily.Cursive
    }
    val base = TextStyle(
        fontSize = style.sizeSp.sp,
        lineHeight = (style.sizeSp * 1.3f).sp,
        fontFamily = family,
        fontWeight = if (style.bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = TextAlign.Center,
        textDirection = TextDirection.Content
    )

    val boxModifier = if (style.boxEnabled) {
        Modifier
            .padding(horizontal = 12.dp)
            .background(Color.Black.copy(alpha = style.boxOpacity), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    } else {
        Modifier.padding(horizontal = 12.dp)
    }

    Box(modifier = boxModifier) {
        if (style.outline) {
            // Black stroke layer underneath, coloured fill on top = outlined text.
            Text(
                text = annotated.text,
                style = base.merge(
                    TextStyle(
                        color = Color.Black,
                        drawStyle = Stroke(width = 7f, join = StrokeJoin.Round)
                    )
                )
            )
        }
        Text(text = annotated, style = base.merge(TextStyle(color = Color(style.textColor))))
    }
}

private fun buildCaptionText(line: CaptionLine, activeWord: Int, highlightColor: Color): AnnotatedString {
    if (line.words.isEmpty()) return AnnotatedString(line.text)
    return buildAnnotatedString {
        line.words.forEachIndexed { index, word ->
            if (index > 0 && word.spaceBefore) append(" ")
            if (index == activeWord) {
                withStyle(SpanStyle(color = highlightColor)) { append(word.text) }
            } else {
                append(word.text)
            }
        }
    }
}

// --------------------------------------------------------------------------------------
// Export
// --------------------------------------------------------------------------------------

@Composable
private fun ExportSection(videoName: String, lines: List<CaptionLine>) {
    val context = LocalContext.current

    fun attempt(block: () -> String?) {
        try {
            val message = block()
            if (message != null) Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Export", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    attempt {
                        FileExporter.saveToDownloads(context, videoName, SubtitleFormat.SRT, SubtitleWriter.toSrt(lines))
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Save .srt") }
            Button(
                onClick = {
                    attempt {
                        FileExporter.saveToDownloads(context, videoName, SubtitleFormat.VTT, SubtitleWriter.toVtt(lines))
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Save .vtt") }
        }
        OutlinedButton(
            onClick = {
                attempt {
                    FileExporter.share(context, videoName, SubtitleFormat.SRT, SubtitleWriter.toSrt(lines))
                    null
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share .srt") }
    }
}

// --------------------------------------------------------------------------------------
// Style panel
// --------------------------------------------------------------------------------------

@Composable
private fun StylePanel(style: CaptionStyle, onChange: (CaptionStyle) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Caption style", style = MaterialTheme.typography.titleMedium)

            SectionLabel("Font")
            ChipRow(CaptionFont.values().toList(), style.font, { it.label }) { onChange(style.copy(font = it)) }

            SectionLabel("Size: ${style.sizeSp.toInt()}")
            Slider(
                value = style.sizeSp,
                onValueChange = { onChange(style.copy(sizeSp = it)) },
                valueRange = 14f..40f
            )

            SectionLabel("Text color")
            ColorRow(TEXT_COLORS, style.textColor) { onChange(style.copy(textColor = it)) }

            SectionLabel("Position")
            ChipRow(CaptionPosition.values().toList(), style.position, { it.name }) {
                onChange(style.copy(position = it))
            }

            SwitchRow("Bold", style.bold) { onChange(style.copy(bold = it)) }
            SwitchRow("Background box", style.boxEnabled) { onChange(style.copy(boxEnabled = it)) }
            if (style.boxEnabled) {
                SectionLabel("Box opacity")
                Slider(
                    value = style.boxOpacity,
                    onValueChange = { onChange(style.copy(boxOpacity = it)) },
                    valueRange = 0.1f..1f
                )
            }
            SwitchRow("Outline", style.outline) { onChange(style.copy(outline = it)) }
            SwitchRow("Highlight the spoken word (CapCut style)", style.wordHighlight) {
                onChange(style.copy(wordHighlight = it))
            }
            if (style.wordHighlight) {
                SectionLabel("Highlight color")
                ColorRow(HIGHLIGHT_COLORS, style.highlightColor) { onChange(style.copy(highlightColor = it)) }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge)
}

@Composable
private fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) }
            )
        }
    }
}

@Composable
private fun ColorRow(colors: List<Long>, selected: Long, onSelect: (Long) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { value ->
            val isSelected = value == selected
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(value))
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray,
                        shape = CircleShape
                    )
                    .clickable { onSelect(value) }
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// --------------------------------------------------------------------------------------
// Caption editor
// --------------------------------------------------------------------------------------

@Composable
private fun LineEditor(
    line: CaptionLine,
    active: Boolean,
    onSeek: () -> Unit,
    onChange: (String) -> Unit
) {
    var local by remember(line.id) { mutableStateOf(line.text) }
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (active) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(12.dp)) {
            TextButton(onClick = onSeek) {
                Text("${SubtitleWriter.shortTime(line.startMs)}  to  ${SubtitleWriter.shortTime(line.endMs)}  (tap to play)")
            }
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = local,
                onValueChange = {
                    local = it
                    onChange(it)
                },
                textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
