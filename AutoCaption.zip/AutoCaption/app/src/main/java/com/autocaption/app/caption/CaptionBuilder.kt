package com.autocaption.app.caption

/** Turns whisper's one-word-per-segment output into readable caption lines. */
object CaptionBuilder {

    private const val SENTENCE_END = ".?!…。！？۔؟।"
    private const val MIN_WORD_MS = 80L
    private const val MIN_LINE_MS = 700L
    private const val MAX_GAP_MS = 700L
    private const val MAX_LINE_MS = 4500L
    private const val MAX_CHARS = 38

    fun fromRaw(raw: List<RawWord>): List<CaptionLine> {
        val words = cleanWords(raw)
        if (words.isEmpty()) return emptyList()
        return groupIntoLines(words)
    }

    fun joinWords(words: List<Word>): String = buildString {
        words.forEachIndexed { index, word ->
            if (index > 0 && word.spaceBefore) append(' ')
            append(word.text)
        }
    }

    /** Called when the user edits the text of a caption: keep timing, re-spread the words. */
    fun withText(line: CaptionLine, newText: String): CaptionLine {
        val tokens = newText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return line.copy(text = newText, words = emptyList())

        val total = (line.endMs - line.startMs).coerceAtLeast(tokens.size * MIN_WORD_MS)
        val weights = tokens.map { it.length.coerceAtLeast(1) }
        val weightSum = weights.sum().toLong()
        var cursor = line.startMs
        val words = tokens.mapIndexed { index, token ->
            val duration = total * weights[index] / weightSum
            val word = Word(token, cursor, cursor + duration, index > 0)
            cursor += duration
            word
        }
        return line.copy(text = newText, words = words)
    }

    private fun cleanWords(raw: List<RawWord>): List<Word> {
        val out = ArrayList<Word>()
        for (r in raw) {
            val trimmed = r.text.trim()
            if (trimmed.isEmpty()) continue
            // Whisper sometimes emits tags such as [BLANK_AUDIO] or (music): not speech.
            if (trimmed.length > 2 &&
                ((trimmed.first() == '[' && trimmed.last() == ']') ||
                        (trimmed.first() == '(' && trimmed.last() == ')'))
            ) continue

            val spaceBefore = r.text.first().isWhitespace()
            val punctuationOnly = trimmed.none { it.isLetterOrDigit() }
            if (!spaceBefore && punctuationOnly && out.isNotEmpty()) {
                // Attach "," "." "?" ... to the previous word.
                val prev = out.removeAt(out.lastIndex)
                out.add(prev.copy(text = prev.text + trimmed, endMs = maxOf(prev.endMs, r.endMs)))
                continue
            }
            out.add(Word(trimmed, r.startMs, r.endMs, spaceBefore))
        }

        // Timing clean-up: monotonic starts, minimum length, no overlap.
        var previousStart = 0L
        for (i in out.indices) {
            val w = out[i]
            val start = maxOf(w.startMs, previousStart)
            val end = maxOf(w.endMs, start + MIN_WORD_MS)
            out[i] = w.copy(startMs = start, endMs = end)
            previousStart = start
        }
        for (i in 0 until out.size - 1) {
            val w = out[i]
            val next = out[i + 1]
            if (w.endMs > next.startMs) {
                out[i] = w.copy(endMs = maxOf(next.startMs, w.startMs + 40))
            }
        }
        return out
    }

    private fun groupIntoLines(words: List<Word>): List<CaptionLine> {
        val spaced = words.count { it.spaceBefore } > words.size / 2
        val maxWords = if (spaced) 7 else 16

        val groups = ArrayList<List<Word>>()
        var current = ArrayList<Word>()

        fun flush() {
            if (current.isNotEmpty()) {
                groups.add(current)
                current = ArrayList()
            }
        }

        for (word in words) {
            if (current.isNotEmpty()) {
                val gap = word.startMs - current.last().endMs
                val duration = word.endMs - current.first().startMs
                val chars = current.sumOf { it.text.length + 1 } + word.text.length
                if (gap > MAX_GAP_MS || duration > MAX_LINE_MS ||
                    current.size >= maxWords || chars > MAX_CHARS
                ) flush()
            }
            current.add(word)
            if (word.text.last() in SENTENCE_END) flush()
        }
        flush()

        return groups.mapIndexed { index, group ->
            val start = group.first().startMs
            val wordsEnd = group.last().endMs
            val nextStart = groups.getOrNull(index + 1)?.first()?.startMs
            // Keep a caption on screen a little longer, but never past the next caption.
            var end = start + MIN_LINE_MS
            if (nextStart != null) end = minOf(end, nextStart)
            end = maxOf(end, wordsEnd)
            CaptionLine(index, start, end, joinWords(group), group)
        }
    }
}
