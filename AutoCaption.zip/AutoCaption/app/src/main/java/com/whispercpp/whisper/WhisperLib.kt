package com.whispercpp.whisper

/** Called from native code while whisper is transcribing. percent = 0..100 */
fun interface WhisperProgressListener {
    fun onProgress(percent: Int)
}

/**
 * Native bindings. The package, class name and the "companion object" layout must match
 * the exported symbols in jni.c (Java_com_whispercpp_whisper_WhisperLib_00024Companion_*).
 */
class WhisperLib {
    companion object {
        init {
            System.loadLibrary("autocaption_jni")
        }

        external fun initContext(modelPath: String): Long
        external fun freeContext(contextPtr: Long)

        /** @return 0 on success */
        external fun fullTranscribe(
            contextPtr: Long,
            numThreads: Int,
            language: String,
            audio: FloatArray,
            listener: WhisperProgressListener?
        ): Int

        external fun getSegmentCount(contextPtr: Long): Int
        external fun getSegmentBytes(contextPtr: Long, index: Int): ByteArray

        /** whisper time unit: 10 ms */
        external fun getSegmentT0(contextPtr: Long, index: Int): Long
        external fun getSegmentT1(contextPtr: Long, index: Int): Long
    }
}
