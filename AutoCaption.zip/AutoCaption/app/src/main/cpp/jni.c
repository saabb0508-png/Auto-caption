// JNI bridge between Kotlin (com.whispercpp.whisper.WhisperLib) and whisper.cpp.
// Naming of the exported symbols follows the official whisper.android example
// (functions live in the Kotlin "companion object" => ..._00024Companion_...).

#include <jni.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "AutoCaptionJNI", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "AutoCaptionJNI", __VA_ARGS__)
#else
#include <stdio.h>
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } while (0)
#define LOGW(...) do { fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } while (0)
#endif

#include "whisper.h"

#define UNUSED(x) (void)(x)

JNIEXPORT jlong JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_initContext(
        JNIEnv *env, jobject thiz, jstring model_path_str) {
    UNUSED(thiz);
    const char *model_path = (*env)->GetStringUTFChars(env, model_path_str, NULL);
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *context = whisper_init_from_file_with_params(model_path, cparams);
    (*env)->ReleaseStringUTFChars(env, model_path_str, model_path);
    if (context == NULL) {
        LOGW("Could not load whisper model");
    }
    return (jlong) context;
}

JNIEXPORT void JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_freeContext(
        JNIEnv *env, jobject thiz, jlong context_ptr) {
    UNUSED(env);
    UNUSED(thiz);
    struct whisper_context *context = (struct whisper_context *) context_ptr;
    if (context != NULL) {
        whisper_free(context);
    }
}

struct progress_ctx {
    JNIEnv *env;
    jobject listener;
    jmethodID method;
    int last;
};

static void on_progress(struct whisper_context *ctx, struct whisper_state *state,
                        int progress, void *user_data) {
    UNUSED(ctx);
    UNUSED(state);
    struct progress_ctx *p = (struct progress_ctx *) user_data;
    if (p == NULL || p->listener == NULL || p->method == NULL) return;
    if (progress == p->last) return;
    p->last = progress;
    // whisper_full() invokes this callback on the thread that called it,
    // which is the same thread that owns p->env.
    (*p->env)->CallVoidMethod(p->env, p->listener, p->method, (jint) progress);
    if ((*p->env)->ExceptionCheck(p->env)) {
        (*p->env)->ExceptionClear(p->env);
    }
}

// Returns 0 on success, non-zero on failure.
JNIEXPORT jint JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_fullTranscribe(
        JNIEnv *env, jobject thiz, jlong context_ptr, jint num_threads,
        jstring language_str, jfloatArray audio_data, jobject listener) {
    UNUSED(thiz);
    struct whisper_context *context = (struct whisper_context *) context_ptr;
    if (context == NULL) return -100;

    const char *language = (*env)->GetStringUTFChars(env, language_str, NULL);
    jfloat *audio = (*env)->GetFloatArrayElements(env, audio_data, NULL);
    const jsize audio_len = (*env)->GetArrayLength(env, audio_data);

    struct progress_ctx pctx;
    pctx.env = env;
    pctx.listener = listener;
    pctx.method = NULL;
    pctx.last = -1;
    if (listener != NULL) {
        jclass cls = (*env)->GetObjectClass(env, listener);
        pctx.method = (*env)->GetMethodID(env, cls, "onProgress", "(I)V");
        (*env)->DeleteLocalRef(env, cls);
        if (pctx.method == NULL && (*env)->ExceptionCheck(env)) {
            (*env)->ExceptionClear(env);
        }
    }

    struct whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime   = false;
    params.print_progress   = false;
    params.print_timestamps = false;
    params.print_special    = false;
    params.translate        = false;
    // "auto" => whisper detects the spoken language itself.
    // NOTE: detect_language must stay false, otherwise whisper only detects and stops.
    params.language         = language;
    params.detect_language  = false;
    params.n_threads        = num_threads;
    params.offset_ms        = 0;
    params.no_context       = true;
    params.single_segment   = false;
    params.suppress_nst     = true;

    // Word-level timestamps: every segment returned is exactly one word.
    params.token_timestamps = true;
    params.max_len          = 1;
    params.split_on_word    = true;
    params.thold_pt         = 0.01f;

    params.progress_callback           = on_progress;
    params.progress_callback_user_data = &pctx;

    whisper_reset_timings(context);
    LOGI("Running whisper_full: %d samples, %d threads, language=%s",
         (int) audio_len, (int) num_threads, language);
    int rc = whisper_full(context, params, audio, audio_len);
    if (rc != 0) {
        LOGW("whisper_full failed: %d", rc);
    }

    (*env)->ReleaseFloatArrayElements(env, audio_data, audio, JNI_ABORT);
    (*env)->ReleaseStringUTFChars(env, language_str, language);
    return rc;
}

JNIEXPORT jint JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_getSegmentCount(
        JNIEnv *env, jobject thiz, jlong context_ptr) {
    UNUSED(env);
    UNUSED(thiz);
    return whisper_full_n_segments((struct whisper_context *) context_ptr);
}

// Raw UTF-8 bytes (not NewStringUTF): with one-word segments a multi-byte character
// can be split across two segments and NewStringUTF would reject invalid UTF-8.
// Kotlin glues such pieces together before decoding.
JNIEXPORT jbyteArray JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_getSegmentBytes(
        JNIEnv *env, jobject thiz, jlong context_ptr, jint index) {
    UNUSED(thiz);
    const char *text = whisper_full_get_segment_text((struct whisper_context *) context_ptr, index);
    if (text == NULL) text = "";
    jsize len = (jsize) strlen(text);
    jbyteArray arr = (*env)->NewByteArray(env, len);
    if (arr != NULL && len > 0) {
        (*env)->SetByteArrayRegion(env, arr, 0, len, (const jbyte *) text);
    }
    return arr;
}

// Times are in units of 10 ms.
JNIEXPORT jlong JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_getSegmentT0(
        JNIEnv *env, jobject thiz, jlong context_ptr, jint index) {
    UNUSED(env);
    UNUSED(thiz);
    return (jlong) whisper_full_get_segment_t0((struct whisper_context *) context_ptr, index);
}

JNIEXPORT jlong JNICALL
Java_com_whispercpp_whisper_WhisperLib_00024Companion_getSegmentT1(
        JNIEnv *env, jobject thiz, jlong context_ptr, jint index) {
    UNUSED(env);
    UNUSED(thiz);
    return (jlong) whisper_full_get_segment_t1((struct whisper_context *) context_ptr, index);
}
