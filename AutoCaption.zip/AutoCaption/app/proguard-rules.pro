# Keep JNI classes and the progress listener called from native code.
-keep class com.whispercpp.whisper.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
